Item.statics

Weapon = Item.extend(function() {
})
.methods ({

});