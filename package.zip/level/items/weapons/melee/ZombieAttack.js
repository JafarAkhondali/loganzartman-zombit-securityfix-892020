ZombieAttack = Melee.extend(function(){
	this.range = 25;
	this.width = 40;
	this.delay = 5;
	this.damage = 5;

	this.name = "ZombieAttack";
	this.type = ZOMBIEATTACK;
})
.methods({

});